# corregidor — profile-level changes

Units with profile/option changes: **19**
Profile-level changes: **13** · Option-level changes: **19**

## [395] Intruders
*INTRUDERS, Corregidor Assault Commandos*

### Profile group 0
- ~ **Profile modified:** INTRUDERS, Corregidor Assault Commandos
    · bts: 0 → 3
- ~ **Option modified:** INTRUDER
    · weapons + Heavy Pistol
    · weapons − Grenades, Pistol


## [400] Corregidor Bandits
*CORREGIDOR BANDITS*

### Profile group 0
- ~ **Profile modified:** CORREGIDOR BANDITS
    · skills + BS Attack(+1SD)
    · skills − BS Attack(+1B)
- ~ **Option modified:** BANDIT
    · points: 24 → 23


## [1578] The Diablos of D-Block
*The DIABLOS of D-Block*

### Profile group 0
- ~ **Profile modified:** The DIABLOS of D-Block
    · skills + Berserk(+3), CC Attack(+1B), Religious Troop
    · skills − Berserk, Courage
- ~ **Profile modified:** BATTLE-RAVAGED
    · skills + Berserk(+3), CC Attack(+1B), Religious Troop
    · skills − Berserk, Courage
- ~ **Option modified:** DIABLO
    · points: 9 → 8
    · weapons + CC Weapon(PS=5), Trench-Hammer(PS=5)
    · weapons − CC Weapon(PS=4), Trench-Hammer(PS=4)


## [432] 'Gecko' Squad
*'GECKO' SQUADRON*

### Profile group 0
- ~ **Profile modified:** 'GECKO' SQUADRON
    · equipment + ECM: Hacker(-3)
- ~ **Option modified:** GECKO
    · points: 52 → 54


## [296] Corregidor Alguaciles
*CORREGIDOR ALGUACILES*

### Profile group 0
- + **Option added:** ALGUACIL GATTA (10 pts, SWC 0)
    · weapons: Submachine Gun, Contender, Pistol, CC Weapon
    · skills: BTS=3


## [415] Tomcats
*TOMCATS, Emergency and Rescue Special Team*

### Profile group 0
- ~ **Option modified:** TOMCAT
    · weapons − Panzerfaust
    · equipment + Deployable Repeater

### Profile group 1
- ~ **Profile modified:** ZONDCATS
    · skills + Climbing Plus


## [1543] Evaders, EVA Tactical Group
*EVADERS, EVA Tactical Group*

### Profile group 0
- ~ **Profile modified:** EVADERS, EVA Tactical Group
    · ava: 5 → 3
    · skills − Specialist Operative
    · equipment + Albedo(-3), Deactivator(ReRoll)
    · equipment − Deactivator
- ~ **Option modified:** EVADER
    · points: 24 → 31
    · SWC: 0 → 1
    · weapons + AP Spitfire
    · weapons − MULTI Rifle, Panzerfaust
    · skills + Specialist Operative
    · equipment + TinBot: Firewall(-3)


## [382] Mobile Brigada
*MOBILE BRIGADA*

### Profile group 0
- ~ **Profile modified:** MOBILE BRIGADA
    · skills + Courage
    · skills − Immunity(Shock), Jump


## [408] Stempler Zonds
*STEMPLER ZONDS*

### Profile group 0
- + **Option added:** STEMPLER ZOND FTO (17 pts, SWC 0)
    · weapons: Combi Rifle, Flash Pulse, PARA CC Weapon(-3)
    · skills: Super-Jump


## [1544] Vostok Sputniks 
*VOSTOK Sputniks*

### Profile group 0
- ~ **Option modified:** VOSTOK
    · points: 40 → 38
    · weapons + Light Shotgun, Mk12
    · weapons − Mk12(PS=4)
- ~ **Option modified:** VOSTOK FTO
    · weapons + Light Shotgun


## [433] Alguacil Vortex Lupe Balboa
*ALGUACIL VORTEX LUPE BALBOA*

### Profile group 0
- ~ **Profile modified:** ALGUACIL VORTEX LUPE BALBOA
    · skills + Immunity(Shock)
    · skills − Courage, Dogged, Specialist Operative
- ~ **Option modified:** LUPE BALBOA
    · points: 24 → 23
    · weapons + AP Submachine Gun
    · weapons − Combi Rifle
    · skills + Chain of Command


## [1580] 'Gator' Squadron
*'GATOR' SQUADRON*

### Profile group 0
- ~ **Profile modified:** 'GATOR' SQUADRON
    · cc: 20 → 21
- ~ **Option modified:** GATOR
    · weapons + Mine Dispenser(AP)
    · weapons − Mine Dispenser(Cybermines)


## [427] Carlota Kowalsky, Tomcats Sergeant
*CARLOTA KOWALSKY, Tomcats Sergeant*

### Profile group 0
- ~ **Option modified:** CARLOTA KOWALSKY
    · points: 29 → 28


## [10325] Bashi Bazouks
*BASHI BAZOUKS*

### Profile group 0
- ~ **Option modified:** BASHI BAZOUK
    · points: 14 → 13
    · weapons + Contender(+1SD)
    · weapons − Contender(+1B)


## [10380] Scarface & Cordelia, Mercenary Armored Team
*SCARFACE & CORDELIA, MERCENARY ARMORED TEAM*

### Profile group 0
- − **Profile removed:** SCARFACE TURNER, T.A.G. MERCENARIO
- + **Profile added:** SCARFACE TURNER, MERCENARY TAG
    · unitType=4, move=[6,4], cc=22, bs=13, ph=16, wip=13, arm=7, bts=6, w=3, s=7, ava=1
    · skills: CC Attack(-3), BS Attack(SR-1), Berserk(+3), Courage, Dodge(PH=11), Gizmokit(PH=11), Tactical Awareness
    · equipment: ECM: Guided(-6), ECM: Hacker(-3)


## [10122] CSU, Corporate Security Unit
*CSU, Corporate Security Unit*

### Profile group 0
- ~ **Option modified:** CSU
    · points: 12 → 10


## [11072] Emily Handelman, Intel Agent
*EMILY HANDELMAN, Intel Agent*

### Profile group 0
- ~ **Option modified:** EMILY
    · points: 23 → 22


## [10198] Father Lucien Sforza, Authorized Bounty Hunter
*FATHER LUCIEN SFORZA, Authorized Bounty Hunter*

### Profile group 0
- ~ **Profile modified:** FATHER LUCIEN SFORZA, Authorized Bounty Hunter
    · skills + BS Attack(+1SD), NCO
    · equipment − Holomask
- ~ **Option modified:** SFORZA
    · points: 28 → 26
    · weapons + Adhesive Launcher Rifle, Heavy Pistol
    · weapons − Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)
- ~ **Option modified:** SFORZA FTO
    · points: 25 → 23
    · weapons + Adhesive Launcher Rifle, Heavy Pistol
    · weapons − Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)


## [10947] Major Lunah, ex-Aristeia! Sniper
*MAJOR LUNAH, ex-Aristeia! Sniper*

### Profile group 0
- ~ **Option modified:** MAJOR LUNAH
    · points: 28 → 29
    · weapons + VIRAL Sniper Rifle(+1SD)
    · weapons − VIRAL Sniper Rifle

