# white-company — profile-level changes

Units with profile/option changes: **8**
Profile-level changes: **3** · Option-level changes: **8**

## [122] CSU, Corporate Security Unit
*CSU, Corporate Security Unit*

### Profile group 0
- ~ **Option modified:** CSU
    · points: 12 → 10


## [1750] Blockers, Attached Agents of the CDCI
*BLOCKERS, Attached Agents of the CDCI*

### Profile group 0
- ~ **Option modified:** BLOCKER
    · weapons + Pitcher


## [380] Scarface & Cordelia, Mercenary Armored Team
*SCARFACE & CORDELIA, MERCENARY ARMORED TEAM*

### Profile group 0
- − **Profile removed:** SCARFACE TURNER, T.A.G. MERCENARIO
- + **Profile added:** SCARFACE TURNER, MERCENARY TAG
    · unitType=4, move=[6,4], cc=22, bs=13, ph=16, wip=13, arm=7, bts=6, w=3, s=7, ava=1
    · skills: CC Attack(-3), BS Attack(SR-1), Berserk(+3), Courage, Dodge(PH=11), Gizmokit(PH=11), Tactical Awareness
    · equipment: ECM: Guided(-6), ECM: Hacker(-3)


## [1072] Emily Handelman, Intel Agent
*EMILY HANDELMAN, Intel Agent*

### Profile group 0
- ~ **Option modified:** EMILY
    · points: 23 → 22


## [10325] Bashi Bazouks
*BASHI BAZOUKS*

### Profile group 0
- ~ **Option modified:** BASHI BAZOUK
    · points: 14 → 13
    · weapons + Contender(+1SD)
    · weapons − Contender(+1B)


## [10122] CSU, Corporate Security Unit
*CSU, Corporate Security Unit*

### Profile group 0
- ~ **Option modified:** CSU
    · points: 12 → 10


## [10198] Father Lucien Sforza, Authorized Bounty Hunter
*FATHER LUCIEN SFORZA, Authorized Bounty Hunter*

### Profile group 0
- ~ **Profile modified:** FATHER LUCIEN SFORZA, Authorized Bounty Hunter
    · skills + BS Attack(+1SD), NCO
    · equipment − Holomask
- ~ **Option modified:** SFORZA
    · points: 28 → 26
    · weapons + Adhesive Launcher Rifle, Heavy Pistol
    · weapons − Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)
- ~ **Option modified:** SFORZA FTO
    · points: 25 → 23
    · weapons + Adhesive Launcher Rifle, Heavy Pistol
    · weapons − Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)


## [10947] Major Lunah, ex-Aristeia! Sniper
*MAJOR LUNAH, ex-Aristeia! Sniper*

### Profile group 0
- ~ **Option modified:** MAJOR LUNAH
    · points: 28 → 29
    · weapons + VIRAL Sniper Rifle(+1SD)
    · weapons − VIRAL Sniper Rifle

