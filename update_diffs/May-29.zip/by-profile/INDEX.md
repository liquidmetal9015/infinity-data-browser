# Per-Faction Profile-Level Change Report

Old: /tmp/snapshot-reprocess
New: /home/clindbeck9/infinity-data
Generated: 2026-05-27T13:13:16.453Z

Mod-aware diff: weapon/skill/equipment changes are reported by their `displayName`,
so e.g. `Mimetism(-6)` is distinguished from `Mimetism(-3)` and `Thunderbolt(+2B)` from `Thunderbolt`.

| Faction | Units w/ profile changes | Profiles changed | Options changed |
|---|---:|---:|---:|
| [aleph](aleph.md) | 18 | 13 | 21 |
| [ariadna](ariadna.md) | 7 | 3 | 7 |
| [bakunin](bakunin.md) | 12 | 4 | 13 |
| [caledonian-highlander-army](caledonian-highlander-army.md) | 6 | 3 | 6 |
| [combined-army](combined-army.md) | 7 | 4 | 7 |
| [corregidor](corregidor.md) | 19 | 13 | 19 |
| [dahshat](dahshat.md) | 7 | 3 | 7 |
| [druze](druze.md) | 8 | 3 | 8 |
| [force-de-reponse-rapide-merovingienne](force-de-reponse-rapide-merovingienne.md) | 8 | 3 | 8 |
| [haqqislam](haqqislam.md) | 10 | 3 | 10 |
| [hassassin-bahram](hassassin-bahram.md) | 8 | 3 | 9 |
| [ikari](ikari.md) | 7 | 3 | 7 |
| [imperial-service](imperial-service.md) | 8 | 4 | 8 |
| [invincible-army](invincible-army.md) | 7 | 3 | 7 |
| [jsa](jsa.md) | 6 | 3 | 6 |
| [kestrel-colonial-force](kestrel-colonial-force.md) | 8 | 5 | 10 |
| [kosmoflot](kosmoflot.md) | 7 | 3 | 7 |
| [military-orders](military-orders.md) | 6 | 3 | 6 |
| [morat](morat.md) | 7 | 4 | 7 |
| [neoterran-capitaline-army](neoterran-capitaline-army.md) | 11 | 5 | 13 |
| [next-wave](next-wave.md) | 6 | 3 | 6 |
| [nomads](nomads.md) | 14 | 7 | 16 |
| [o-12](o-12.md) | 7 | 3 | 7 |
| [oban](oban.md) | 6 | 3 | 6 |
| [onyx](onyx.md) | 7 | 4 | 7 |
| [operations](operations.md) | 20 | 16 | 27 |
| [panoceania](panoceania.md) | 9 | 5 | 11 |
| [qapu-khalqi](qapu-khalqi.md) | 7 | 3 | 7 |
| [ramah-taskforce](ramah-taskforce.md) | 8 | 3 | 8 |
| [shasvastii](shasvastii.md) | 7 | 4 | 7 |
| [shindenbutai](shindenbutai.md) | 6 | 3 | 6 |
| [shock-army-of-acontecimento](shock-army-of-acontecimento.md) | 7 | 3 | 7 |
| [starco-free-company-of-the-star](starco-free-company-of-the-star.md) | 10 | 4 | 11 |
| [starmada](starmada.md) | 6 | 3 | 6 |
| [steel-phalanx](steel-phalanx.md) | 8 | 4 | 7 |
| [svalarheima-s-winter-force](svalarheima-s-winter-force.md) | 7 | 3 | 7 |
| [tartary](tartary.md) | 6 | 3 | 6 |
| [tohaa](tohaa.md) | 14 | 3 | 14 |
| [torchlight-brigade](torchlight-brigade.md) | 7 | 3 | 7 |
| [tunguska](tunguska.md) | 10 | 3 | 12 |
| [usariadna](usariadna.md) | 6 | 3 | 6 |
| [varuna-immediate-reaction-division](varuna-immediate-reaction-division.md) | 7 | 3 | 7 |
| [white-banner](white-banner.md) | 6 | 3 | 6 |
| [white-company](white-company.md) | 8 | 3 | 8 |
| [yu-jing](yu-jing.md) | 7 | 4 | 7 |

**Totals:** units=383, profile changes=187, option changes=405