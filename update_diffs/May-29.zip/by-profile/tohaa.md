# tohaa — profile-level changes

Units with profile/option changes: **14**
Profile-level changes: **3** · Option-level changes: **14**

## [1552] Rasail Boarding Team
*RASAIL Boarding Team*

### Profile group 0
- ~ **Option modified:** RASAIL 
    · points: 30 → 31
    · weapons + Viral Combi Rifle
    · weapons − Combi Rifle, Shock Mine


## [647] Sakiel Regiment
*SAKIEL Regiment*

### Profile group 0
- ~ **Option modified:** SAKIEL
    · points: 23 → 19


## [660] Nikoul Ambush Unit
*NIKOUL AMBUSH UNIT*

### Profile group 0
- ~ **Option modified:** NIKOUL
    · points: 27 → 25


## [1304] Taagma Schemers
*TAAGMA Schemers*

### Profile group 0
- ~ **Option modified:** TAAGMA
    · points: 16 → 15


## [1307] Kriigel Agents
*KRIIGEL Agents*

### Profile group 0
- ~ **Option modified:** KRIIGEL
    · points: 22 → 21


## [650] Ectros Regiment
*ECTROS Regiment*

### Profile group 0
- ~ **Option modified:** ECTROS
    · points: 37 → 33


## [657] Neema Saatar, Ectros Regiment Officer
*NEEMA SAATAR, Ectros Regiment Officer*

### Profile group 0
- ~ **Option modified:** NEEMA
    · weapons + Viral CC Weapon(PS=5)
    · weapons − Shock CC Weapon(PS=5)


## [801] Taqeul Officers
*TAQEUL Officers*

### Profile group 0
- ~ **Option modified:** TAQEUL
    · points: 34 → 36
    · weapons + Viral Combi Rifle
    · weapons − Combi Rifle


## [10325] Bashi Bazouks
*BASHI BAZOUKS*

### Profile group 0
- ~ **Option modified:** BASHI BAZOUK
    · points: 14 → 13
    · weapons + Contender(+1SD)
    · weapons − Contender(+1B)


## [11072] Emily Handelman, Intel Agent
*EMILY HANDELMAN, Intel Agent*

### Profile group 0
- ~ **Option modified:** EMILY
    · points: 23 → 22


## [10380] Scarface & Cordelia, Mercenary Armored Team
*SCARFACE & CORDELIA, MERCENARY ARMORED TEAM*

### Profile group 0
- − **Profile removed:** SCARFACE TURNER, T.A.G. MERCENARIO
- + **Profile added:** SCARFACE TURNER, MERCENARY TAG
    · unitType=4, move=[6,4], cc=22, bs=13, ph=16, wip=13, arm=7, bts=6, w=3, s=7, ava=1
    · skills: CC Attack(-3), BS Attack(SR-1), Berserk(+3), Courage, Dodge(PH=11), Gizmokit(PH=11), Tactical Awareness
    · equipment: ECM: Guided(-6), ECM: Hacker(-3)


## [10122] CSU, Corporate Security Unit
*CSU, Corporate Security Unit*

### Profile group 0
- ~ **Option modified:** CSU
    · points: 12 → 10


## [10198] Father Lucien Sforza, Authorized Bounty Hunter
*FATHER LUCIEN SFORZA, Authorized Bounty Hunter*

### Profile group 0
- ~ **Profile modified:** FATHER LUCIEN SFORZA, Authorized Bounty Hunter
    · skills + BS Attack(+1SD), NCO
    · equipment − Holomask
- ~ **Option modified:** SFORZA
    · points: 28 → 26
    · weapons + Adhesive Launcher Rifle, Heavy Pistol
    · weapons − Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)
- ~ **Option modified:** SFORZA FTO
    · points: 25 → 23
    · weapons + Adhesive Launcher Rifle, Heavy Pistol
    · weapons − Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)


## [10947] Major Lunah, ex-Aristeia! Sniper
*MAJOR LUNAH, ex-Aristeia! Sniper*

### Profile group 0
- ~ **Option modified:** MAJOR LUNAH
    · points: 28 → 29
    · weapons + VIRAL Sniper Rifle(+1SD)
    · weapons − VIRAL Sniper Rifle

