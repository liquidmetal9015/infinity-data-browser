# aleph — profile-level changes

Units with profile/option changes: **18**
Profile-level changes: **13** · Option-level changes: **21**

## [1720] Maximus, Optimate and HexaDome Legend
*MAXIMUS, Optimate and HexaDome Legend*

### Profile group 0
- ~ **Option modified:** MAXIMUS OPTIMATE
    · points: 76 → 82
    · SWC: 0.5 → 1.5
    · weapons + AP Heavy Machine Gun
    · weapons − Thunderbolt(+2B)

### Profile group 1
- ~ **Profile modified:** OPERATOR MAXIMUS
    · cc: 23 → 22
    · bs: 12 → 13
- ~ **Option modified:** OPERATOR MAXIMUS
    · points: 76 → 82
    · weapons + AP Heavy Machine Gun
    · weapons − Thunderbolt(+2B)


## [1129] Yadu Troopers, Tactical Assault Teams
*YADU Troopers, Tactical Assault Teams*

### Profile group 0
- ~ **Profile modified:** YADU Troopers, Tactical Assault Teams
    · ph: 12 → 11
    · bts: 3 → 6
    · equipment + Albedo(-6)


## [1862] Optimate Agent Maximus
*Optimate Agent Maximus*

### Profile group 0
- ~ **Profile modified:** Optimate Agent MAXIMUS
    · cc: 23 → 22
    · bs: 12 → 13
    · skills + Number 2
    · equipment + Albedo(-3)
- ~ **Option modified:** MAXIMUS AGENT
    · points: 40 → 48
    · weapons + Thunderbolt AP(+2B)
    · weapons − Thunderbolt(+2B)
- + **Option added:** MAXIMUS AGENT FTO (45 pts, SWC 1)
    · weapons: Thunderbolt AP(+2B), E/M Carbine, Heavy Pistol, AP + DA CC Weapon(PS=6)
    · equipment: Tinbot (Repeater)

- + **Profile group 1 added** (1 profiles, 1 options)

## [597] Posthumans
*POST-HUMANS*

### Profile group 1
- ~ **Option modified:** PROXY Mk.2
    · points: 28 → 26

### Profile group 2
- ~ **Profile modified:** PROXY Mk.4
    · bs: 13 → 14
    · skills + BS Attack(-3), Immunity(AP)
- ~ **Option modified:** PROXY Mk.4
    · points: 25 → 30

### Profile group 3
- ~ **Option modified:** PROXY Mk.5
    · points: 18 → 21
    · weapons + Heavy Pistol
    · weapons − Pistol
    · skills + BS Attack(+1SD)
    · skills − Triangulated Fire


## [59] Nagas
*NAGAS*

### Profile group 0
- ~ **Option modified:** NAGA
    · points: 24 → 29
    · SWC: 0 → 1.5
    · weapons + MULTI Sniper Rifle, Nanopulser
    · weapons − Boarding Shotgun, Shock Mine
    · skills + BS Attack(+1SD)


## [587] Dasyus
*DASYUS*

### Profile group 0
- ~ **Profile modified:** DASYUS
    · move: [4,4] → [6,5]
    · cc: 15 → 16
    · bs: 12 → 13
    · ph: 13 → 12
    · bts: 0 → 3
    · skills + BS Attack(+1SD), Immunity(Shock), Infiltration(ReRoll)
    · skills − Infiltration, NCO, No Wound Incapacitation
- ~ **Option modified:** DASYU
    · points: 34 → 28
    · weapons + D-Charges, Pulzar, Silenced Pistol(PS=7)
    · weapons − Shock Mine, Silenced Pistol


## [185] Sophotects
*SOPHOTECTS*

### Profile group 0
- ~ **Profile modified:** SOPHOTECTS
    · equipment + GizmoKit(+1B), MediKit
    · equipment − GizmoKit, MediKit(+1B)
- ~ **Option modified:** SOPHOTECT
    · points: 29 → 25
    · weapons + Flash Pulse, Submachine Gun
    · weapons − Combi Rifle


## [1771] Artalis Unit
*Artalis Unit*

### Profile group 0
- ~ **Profile modified:** ARTALIS
    · skills + BS Attack(SR-1)
    · skills − Courage
    · equipment + Deactivator(ReRoll)
    · equipment − Deactivator


## [584] Asuras
*ASURAS*

### Profile group 0
- ~ **Profile modified:** ASURAS
    · equipment + ECM: Hacker(-3)
- ~ **Option modified:** ASURA
    · points: 58 → 61
    · weapons + AP Spitfire, MULTI Pistol, Pulzar
    · weapons − Nanopulser, Pistol, Spitfire


## [1557] Chandra Specialist Operative Trisha N33
*Chandra Specialist Operative TRISHA N33*

### Profile group 0
- ~ **Profile modified:** Chandra Specialist Operative TRISHA N33
    · ph: 11 → 10
    · arm: 1 → 2
    · equipment + Deactivator(+1B), GizmoKit(+1B)
    · equipment − Deactivator, GizmoKit
- ~ **Option modified:** TRISHA
    · points: 25 → 24
    · weapons + Jammer, Pulzar
    · weapons − E/M Mine, Nanopulser


## [1471] Hippolyta, Amazon Officer
*HIPPOLYTA, Amazon Officer*

### Profile group 0
- ~ **Option modified:** HIPPOLYTA
    · points: 38 → 37


## [1197] Rudras GunBots
*RUDRAS GunBots*

### Profile group 0
- ~ **Profile modified:** RUDRAS GunBots
    · move: [6,4] → [6,5]
    · cc: 13 → 11
    · bs: 12 → 13
    · ph: 10 → 11
    · skills + BS Attack(-3), BS Attack(SR-1), Immunity(AP), Tech-recovery
    · skills − Dodge(+1")
    · equipment + ECM: Hacker(-3)
    · equipment − X Visor
- ~ **Option modified:** RUDRA
    · points: 34 → 38
    · SWC: 0 → 1
    · weapons + Panzerfaust(+1SD), Pulzar, Red Fury
    · weapons − MULTI Rifle(PS=6), Mine Dispenser(Shock)
- + **Option added:** RUDRA FTO (35 pts, SWC 0)
    · weapons: K1 Marksman Rifle, Pulzar, Panzerfaust, Heavy Pistol, PARA CC Weapon(-3)


## [10325] Bashi Bazouks
*BASHI BAZOUKS*

### Profile group 0
- ~ **Option modified:** BASHI BAZOUK
    · points: 14 → 13
    · weapons + Contender(+1SD)
    · weapons − Contender(+1B)


## [11072] Emily Handelman, Intel Agent
*EMILY HANDELMAN, Intel Agent*

### Profile group 0
- ~ **Option modified:** EMILY
    · points: 23 → 22


## [10380] Scarface & Cordelia, Mercenary Armored Team
*SCARFACE & CORDELIA, MERCENARY ARMORED TEAM*

### Profile group 0
- − **Profile removed:** SCARFACE TURNER, T.A.G. MERCENARIO
- + **Profile added:** SCARFACE TURNER, MERCENARY TAG
    · unitType=4, move=[6,4], cc=22, bs=13, ph=16, wip=13, arm=7, bts=6, w=3, s=7, ava=1
    · skills: CC Attack(-3), BS Attack(SR-1), Berserk(+3), Courage, Dodge(PH=11), Gizmokit(PH=11), Tactical Awareness
    · equipment: ECM: Guided(-6), ECM: Hacker(-3)


## [10122] CSU, Corporate Security Unit
*CSU, Corporate Security Unit*

### Profile group 0
- ~ **Option modified:** CSU
    · points: 12 → 10


## [10198] Father Lucien Sforza, Authorized Bounty Hunter
*FATHER LUCIEN SFORZA, Authorized Bounty Hunter*

### Profile group 0
- ~ **Profile modified:** FATHER LUCIEN SFORZA, Authorized Bounty Hunter
    · skills + BS Attack(+1SD), NCO
    · equipment − Holomask
- ~ **Option modified:** SFORZA
    · points: 28 → 26
    · weapons + Adhesive Launcher Rifle, Heavy Pistol
    · weapons − Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)
- ~ **Option modified:** SFORZA FTO
    · points: 25 → 23
    · weapons + Adhesive Launcher Rifle, Heavy Pistol
    · weapons − Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)


## [10947] Major Lunah, ex-Aristeia! Sniper
*MAJOR LUNAH, ex-Aristeia! Sniper*

### Profile group 0
- ~ **Option modified:** MAJOR LUNAH
    · points: 28 → 29
    · weapons + VIRAL Sniper Rifle(+1SD)
    · weapons − VIRAL Sniper Rifle

