# bakunin — profile-level changes

Units with profile/option changes: **12**
Profile-level changes: **4** · Option-level changes: **13**

## [1544] Vostok Sputniks 
*VOSTOK Sputniks*

### Profile group 0
- ~ **Option modified:** VOSTOK
    · points: 40 → 38
    · weapons + Light Shotgun, Mk12
    · weapons − Mk12(PS=4)
- ~ **Option modified:** VOSTOK FTO
    · weapons + Light Shotgun


## [1608] Mother Healer Agatha Wabara
*MOTHER HEALER AGATHA WABARA*

### Profile group 0
- ~ **Option modified:** MOTHER AGATHA
    · points: 32 → 31


## [1555] Wolfgang Amadeus Wolff, Wulver Bounty Hunter
*WOLFGANG AMADEUS WOLFF, Wulver Bounty Hunter*

### Profile group 0
- ~ **Option modified:** WOLFGANG AMADEUS
    · points: 34 → 33
    · weapons + E/M Grenades(+1SD), MULTI Rifle(+1SD)
    · weapons − E/M Grenades(+1B), MULTI Rifle(+1B)


## [423] Tsyklon Sputniks
*TSYKLON Sputnik*

### Profile group 0
- − **Option removed:** TSYKLON (was 26 pts)
- + **Option added:** TSYKLON FTO (26 pts, SWC 1)
    · weapons: Spitfire, Chain Rifle, Pitcher, PARA CC Weapon(-6)


## [399] Lizard Squadron
*LIZARD SQUADRON*

### Profile group 0
- ~ **Profile modified:** LIZARD SQUADRON
    · ava: 2 → 1


## [408] Stempler Zonds
*STEMPLER ZONDS*

### Profile group 0
- + **Option added:** STEMPLER ZOND FTO (17 pts, SWC 0)
    · weapons: Combi Rifle, Flash Pulse, PARA CC Weapon(-3)
    · skills: Super-Jump


## [10325] Bashi Bazouks
*BASHI BAZOUKS*

### Profile group 0
- ~ **Option modified:** BASHI BAZOUK
    · points: 14 → 13
    · weapons + Contender(+1SD)
    · weapons − Contender(+1B)


## [11072] Emily Handelman, Intel Agent
*EMILY HANDELMAN, Intel Agent*

### Profile group 0
- ~ **Option modified:** EMILY
    · points: 23 → 22


## [10380] Scarface & Cordelia, Mercenary Armored Team
*SCARFACE & CORDELIA, MERCENARY ARMORED TEAM*

### Profile group 0
- − **Profile removed:** SCARFACE TURNER, T.A.G. MERCENARIO
- + **Profile added:** SCARFACE TURNER, MERCENARY TAG
    · unitType=4, move=[6,4], cc=22, bs=13, ph=16, wip=13, arm=7, bts=6, w=3, s=7, ava=1
    · skills: CC Attack(-3), BS Attack(SR-1), Berserk(+3), Courage, Dodge(PH=11), Gizmokit(PH=11), Tactical Awareness
    · equipment: ECM: Guided(-6), ECM: Hacker(-3)


## [10122] CSU, Corporate Security Unit
*CSU, Corporate Security Unit*

### Profile group 0
- ~ **Option modified:** CSU
    · points: 12 → 10


## [10198] Father Lucien Sforza, Authorized Bounty Hunter
*FATHER LUCIEN SFORZA, Authorized Bounty Hunter*

### Profile group 0
- ~ **Profile modified:** FATHER LUCIEN SFORZA, Authorized Bounty Hunter
    · skills + BS Attack(+1SD), NCO
    · equipment − Holomask
- ~ **Option modified:** SFORZA
    · points: 28 → 26
    · weapons + Adhesive Launcher Rifle, Heavy Pistol
    · weapons − Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)
- ~ **Option modified:** SFORZA FTO
    · points: 25 → 23
    · weapons + Adhesive Launcher Rifle, Heavy Pistol
    · weapons − Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)


## [10947] Major Lunah, ex-Aristeia! Sniper
*MAJOR LUNAH, ex-Aristeia! Sniper*

### Profile group 0
- ~ **Option modified:** MAJOR LUNAH
    · points: 28 → 29
    · weapons + VIRAL Sniper Rifle(+1SD)
    · weapons − VIRAL Sniper Rifle

