# nomads — profile-level changes

Units with profile/option changes: **14**
Profile-level changes: **7** · Option-level changes: **16**

## [423] Tsyklon Sputniks
*TSYKLON Sputnik*

### Profile group 0
- ~ **Option modified:** TSYKLON
    · points: 26 → 31
    · weapons + Feuerbach
    · weapons − Spitfire
    · skills + Forward Deployment(+4")
- + **Option added:** TSYKLON FTO (26 pts, SWC 1)
    · weapons: Spitfire, Chain Rifle, Pitcher, PARA CC Weapon(-6)


## [1555] Wolfgang Amadeus Wolff, Wulver Bounty Hunter
*WOLFGANG AMADEUS WOLFF, Wulver Bounty Hunter*

### Profile group 0
- ~ **Option modified:** WOLFGANG AMADEUS
    · points: 34 → 33
    · weapons + E/M Grenades(+1SD), MULTI Rifle(+1SD)
    · weapons − E/M Grenades(+1B), MULTI Rifle(+1B)


## [1543] Evaders, EVA Tactical Group
*EVADERS, EVA Tactical Group*

### Profile group 0
- ~ **Profile modified:** EVADERS, EVA Tactical Group
    · skills − Specialist Operative
    · equipment + Albedo(-3), Deactivator(ReRoll)
    · equipment − Deactivator
- ~ **Option modified:** EVADER
    · points: 24 → 31
    · SWC: 0 → 1
    · weapons + AP Spitfire
    · weapons − MULTI Rifle, Panzerfaust
    · skills + Specialist Operative
    · equipment + TinBot: Firewall(-3)


## [1580] 'Gator' Squadron
*'GATOR' SQUADRON*

### Profile group 0
- ~ **Profile modified:** 'GATOR' SQUADRON
    · cc: 20 → 21
- ~ **Option modified:** GATOR
    · weapons + Mine Dispenser(AP)
    · weapons − Mine Dispenser(Cybermines)


## [432] 'Gecko' Squad
*'GECKO' SQUADRON*

### Profile group 0
- ~ **Profile modified:** 'GECKO' SQUADRON
    · equipment + ECM: Hacker(-3)
- ~ **Option modified:** GECKO
    · points: 52 → 54


## [408] Stempler Zonds
*STEMPLER ZONDS*

### Profile group 0
- + **Option added:** STEMPLER ZOND FTO (17 pts, SWC 0)
    · weapons: Combi Rifle, Flash Pulse, PARA CC Weapon(-3)
    · skills: Super-Jump


## [1544] Vostok Sputniks 
*VOSTOK Sputniks*

### Profile group 0
- ~ **Option modified:** VOSTOK
    · points: 40 → 38
    · weapons + Light Shotgun, Mk12
    · weapons − Mk12(PS=4)
- ~ **Option modified:** VOSTOK FTO
    · weapons + Light Shotgun


## [395] Intruders
*INTRUDERS, Corregidor Assault Commandos*

### Profile group 0
- ~ **Profile modified:** INTRUDERS, Corregidor Assault Commandos
    · bts: 0 → 3
- ~ **Option modified:** INTRUDER
    · weapons + Heavy Pistol
    · weapons − Grenades, Pistol


## [10325] Bashi Bazouks
*BASHI BAZOUKS*

### Profile group 0
- ~ **Option modified:** BASHI BAZOUK
    · points: 14 → 13
    · weapons + Contender(+1SD)
    · weapons − Contender(+1B)


## [11072] Emily Handelman, Intel Agent
*EMILY HANDELMAN, Intel Agent*

### Profile group 0
- ~ **Option modified:** EMILY
    · points: 23 → 22


## [10380] Scarface & Cordelia, Mercenary Armored Team
*SCARFACE & CORDELIA, MERCENARY ARMORED TEAM*

### Profile group 0
- − **Profile removed:** SCARFACE TURNER, T.A.G. MERCENARIO
- + **Profile added:** SCARFACE TURNER, MERCENARY TAG
    · unitType=4, move=[6,4], cc=22, bs=13, ph=16, wip=13, arm=7, bts=6, w=3, s=7, ava=1
    · skills: CC Attack(-3), BS Attack(SR-1), Berserk(+3), Courage, Dodge(PH=11), Gizmokit(PH=11), Tactical Awareness
    · equipment: ECM: Guided(-6), ECM: Hacker(-3)


## [10122] CSU, Corporate Security Unit
*CSU, Corporate Security Unit*

### Profile group 0
- ~ **Option modified:** CSU
    · points: 12 → 10


## [10198] Father Lucien Sforza, Authorized Bounty Hunter
*FATHER LUCIEN SFORZA, Authorized Bounty Hunter*

### Profile group 0
- ~ **Profile modified:** FATHER LUCIEN SFORZA, Authorized Bounty Hunter
    · skills + BS Attack(+1SD), NCO
    · equipment − Holomask
- ~ **Option modified:** SFORZA
    · points: 28 → 26
    · weapons + Adhesive Launcher Rifle, Heavy Pistol
    · weapons − Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)
- ~ **Option modified:** SFORZA FTO
    · points: 25 → 23
    · weapons + Adhesive Launcher Rifle, Heavy Pistol
    · weapons − Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)


## [10947] Major Lunah, ex-Aristeia! Sniper
*MAJOR LUNAH, ex-Aristeia! Sniper*

### Profile group 0
- ~ **Option modified:** MAJOR LUNAH
    · points: 28 → 29
    · weapons + VIRAL Sniper Rifle(+1SD)
    · weapons − VIRAL Sniper Rifle

