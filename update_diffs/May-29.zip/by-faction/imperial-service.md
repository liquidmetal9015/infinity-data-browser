# imperial-service

Units: 90 → 89
Added: 0 · Removed: 1 · Modified: 8

## Removed units
- **[183] Dakini Tacbots** / DAKINI Tacbots — was 13-21 pts

## Modified units
### [122] CSU, Corporate Security Unit / CSU, Corporate Security Unit
- **Points:** 11-14 → 10-13
- **Weapons removed:** Nanopulser

### [947] Major Lunah, ex-Aristeia! Sniper / MAJOR LUNAH, ex-Aristeia! Sniper
- **Points:** 28 → 29
- **Weapons added:** VIRAL Sniper Rifle(+1SD)
- **Weapons removed:** VIRAL Sniper Rifle

### [1839] Lóngwáng, Imperial TAG Police / LÓNGWÁNG, Imperial TAG Police
- **Points:** 72-74 → 68-72
- **Weapons added:** AP Heavy Machine Gun, Light Riotstopper, Light Riotstopper(+1B)
- **Weapons removed:** Heavy Machine Gun, Heavy Riotstopper, Heavy Riotstopper(+1B)

### [125] Zhànyīng Imperial Agents / ZHÀNYĪNG Imperial Agents
- **Points:** 21-26 → 20-26

### [198] Father Lucien Sforza, Authorized Bounty Hunter / FATHER LUCIEN SFORZA, Authorized Bounty Hunter
- **Points:** 25-28 → 23-26
- **Weapons added:** Adhesive Launcher Rifle, Heavy Pistol
- **Weapons removed:** Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)
- **Skills added:** BS Attack(+1SD), NCO
- **Equipment added:** Albedo(-6)
- **Equipment removed:** Holomask

### [10325] Bashi Bazouks / BASHI BAZOUKS
- **Points:** 13-16 → 12-16
- **Weapons added:** Contender(+1SD)
- **Weapons removed:** Contender(+1B)

### [10122] CSU, Corporate Security Unit / CSU, Corporate Security Unit
- **Points:** 11-14 → 10-13
- **Weapons removed:** Nanopulser

### [11072] Emily Handelman, Intel Agent / EMILY HANDELMAN, Intel Agent
- **Points:** 23-24 → 22-24
