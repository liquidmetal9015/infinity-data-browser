# tohaa

Units: 87 → 87
Added: 0 · Removed: 0 · Modified: 13

## Modified units
### [1552] Rasail Boarding Team / RASAIL Boarding Team
- **Weapons removed:** Combi Rifle

### [647] Sakiel Regiment / SAKIEL Regiment
- **Points:** 18-23 → 19-22
- **Weapons removed:** Combi Rifle

### [1298] Greif Operators / GREIF OPERATORS
- **Points:** 20-25 → 21-25
- **Weapons added:** Breaker Combi Rifle, Silenced Pistol(+1B)

### [660] Nikoul Ambush Unit / NIKOUL AMBUSH UNIT
- **Points:** 27-29 → 25-27

### [1304] Taagma Schemers / TAAGMA Schemers
- **Points:** 16-24 → 15-22

### [1307] Kriigel Agents / KRIIGEL Agents
- **Points:** 22 → 21

### [657] Neema Saatar, Ectros Regiment Officer / NEEMA SAATAR, Ectros Regiment Officer
- **Weapons added:** Viral CC Weapon(PS=5)

### [801] Taqeul Officers / TAQEUL Officers
- **Points:** 33-40 → 35-36
- **Weapons removed:** Combi Rifle

### [10325] Bashi Bazouks / BASHI BAZOUKS
- **Points:** 13-16 → 12-16
- **Weapons added:** Contender(+1SD)
- **Weapons removed:** Contender(+1B)

### [11072] Emily Handelman, Intel Agent / EMILY HANDELMAN, Intel Agent
- **Points:** 23-24 → 22-24

### [10122] CSU, Corporate Security Unit / CSU, Corporate Security Unit
- **Points:** 11-14 → 10-13
- **Weapons removed:** Nanopulser

### [10198] Father Lucien Sforza, Authorized Bounty Hunter / FATHER LUCIEN SFORZA, Authorized Bounty Hunter
- **Points:** 25-28 → 23-26
- **Weapons added:** Adhesive Launcher Rifle, Heavy Pistol
- **Weapons removed:** Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)
- **Skills added:** BS Attack(+1SD), NCO
- **Equipment added:** Albedo(-6)
- **Equipment removed:** Holomask

### [10947] Major Lunah, ex-Aristeia! Sniper / MAJOR LUNAH, ex-Aristeia! Sniper
- **Points:** 28 → 29
- **Weapons added:** VIRAL Sniper Rifle(+1SD)
- **Weapons removed:** VIRAL Sniper Rifle
