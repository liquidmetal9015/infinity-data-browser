# qapu-khalqi

Units: 82 → 83
Added: 1 · Removed: 0 · Modified: 8

## Added units
- **[1894] Dr. Claire Lazhari, Genephilosopher and Optimate** / Dr. Claire Lazhari, Genephilosopher and Optimate — 33 pts

## Modified units
### [383] 'Iguana' Squadron / 'IGUANA' SQUADRON
- **Points:** 64 → 64-68
- **Skills added:** BS Attack(-3)

### [324] Odalisques / ODALISQUES
- **Points:** 19-28 → 19-27
- **Weapons added:** Breaker Marksman Rifle
- **Weapons removed:** Viral Marksman Rifle

### [325] Bashi Bazouks / BASHI BAZOUKS
- **Points:** 13-16 → 12-16
- **Weapons added:** Contender(+1SD)
- **Weapons removed:** Contender(+1B)

### [10325] Bashi Bazouks / BASHI BAZOUKS
- **Points:** 13-16 → 12-16
- **Weapons added:** Contender(+1SD)
- **Weapons removed:** Contender(+1B)

### [10122] CSU, Corporate Security Unit / CSU, Corporate Security Unit
- **Points:** 11-14 → 10-13
- **Weapons removed:** Nanopulser

### [11072] Emily Handelman, Intel Agent / EMILY HANDELMAN, Intel Agent
- **Points:** 23-24 → 22-24

### [10198] Father Lucien Sforza, Authorized Bounty Hunter / FATHER LUCIEN SFORZA, Authorized Bounty Hunter
- **Points:** 25-28 → 23-26
- **Weapons added:** Adhesive Launcher Rifle, Heavy Pistol
- **Weapons removed:** Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)
- **Skills added:** BS Attack(+1SD), NCO
- **Equipment added:** Albedo(-6)
- **Equipment removed:** Holomask

### [10947] Major Lunah, ex-Aristeia! Sniper / MAJOR LUNAH, ex-Aristeia! Sniper
- **Points:** 28 → 29
- **Weapons added:** VIRAL Sniper Rifle(+1SD)
- **Weapons removed:** VIRAL Sniper Rifle
