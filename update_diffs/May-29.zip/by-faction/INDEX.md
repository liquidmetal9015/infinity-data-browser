# Per-Faction Change Report

Old: /tmp/snapshot-reprocess
New: /home/clindbeck9/infinity-data
Generated: 2026-05-27T13:17:22.292Z

| Faction | Added | Removed | Modified | Old→New units |
|---|---:|---:|---:|---|
| aleph | 12 | 1 | 19 | 86 → 97 |
| ariadna | 0 | 0 | 6 | 100 → 100 |
| bakunin | 2 | 1 | 10 | 93 → 94 |
| caledonian-highlander-army | 0 | 0 | 5 | 71 → 71 |
| combined-army | 0 | 0 | 8 | 100 → 100 |
| corregidor | 6 | 3 | 21 | 84 → 87 |
| dahshat | 0 | 0 | 7 | 83 → 83 |
| druze | 0 | 0 | 7 | 78 → 78 |
| force-de-reponse-rapide-merovingienne | 0 | 0 | 7 | 69 → 69 |
| haqqislam | 2 | 0 | 11 | 101 → 103 |
| hassassin-bahram | 1 | 0 | 11 | 80 → 81 |
| ikari | 0 | 0 | 6 | 82 → 82 |
| imperial-service | 0 | 1 | 8 | 90 → 89 |
| invincible-army | 1 | 0 | 6 | 82 → 83 |
| jsa | 0 | 0 | 5 | 90 → 90 |
| kestrel-colonial-force | 0 | 0 | 8 | 86 → 86 |
| kosmoflot | 0 | 0 | 6 | 84 → 84 |
| military-orders | 0 | 0 | 6 | 86 → 86 |
| morat | 0 | 0 | 6 | 85 → 85 |
| neoterran-capitaline-army | 0 | 0 | 9 | 84 → 84 |
| next-wave | 0 | 0 | 7 | 84 → 84 |
| nomads | 7 | 2 | 15 | 97 → 102 |
| o-12 | 1 | 0 | 6 | 96 → 97 |
| oban | 0 | 0 | 5 | 80 → 80 |
| onyx | 0 | 0 | 8 | 85 → 85 |
| operations | 11 | 4 | 20 | 88 → 95 |
| panoceania | 2 | 0 | 8 | 100 → 102 |
| qapu-khalqi | 1 | 0 | 8 | 82 → 83 |
| ramah-taskforce | 1 | 0 | 7 | 82 → 83 |
| shasvastii | 0 | 0 | 6 | 78 → 78 |
| shindenbutai | 0 | 0 | 5 | 80 → 80 |
| shock-army-of-acontecimento | 0 | 0 | 8 | 78 → 78 |
| starco-free-company-of-the-star | 0 | 1 | 9 | 77 → 76 |
| starmada | 0 | 0 | 5 | 90 → 90 |
| steel-phalanx | 1 | 0 | 7 | 83 → 84 |
| svalarheima-s-winter-force | 1 | 0 | 6 | 82 → 83 |
| tartary | 0 | 0 | 5 | 78 → 78 |
| tohaa | 0 | 0 | 13 | 87 → 87 |
| torchlight-brigade | 1 | 0 | 6 | 84 → 85 |
| tunguska | 2 | 1 | 12 | 88 → 89 |
| usariadna | 0 | 0 | 5 | 70 → 70 |
| varuna-immediate-reaction-division | 0 | 0 | 6 | 77 → 77 |
| white-banner | 1 | 0 | 5 | 93 → 94 |
| white-company | 0 | 0 | 6 | 83 → 83 |
| yu-jing | 2 | 0 | 7 | 102 → 104 |

**Totals:** added=55, removed=14, modified=367

## Unresolved IDs

These IDs appear in unit data but have no entry in either snapshot or current metadata.
`scripts/refresh_data.ts` only refreshes per-faction data, not `data/metadata.json`,
so newly-added game elements (e.g. "AP Red Fury" weapon, "Dodge (ARM+3)" mod) lack names.

- Weapons: (none)
- Skills: (none)
- Equipment: (none)