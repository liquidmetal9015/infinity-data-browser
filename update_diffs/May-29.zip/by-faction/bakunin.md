# bakunin

Units: 93 → 94
Added: 2 · Removed: 1 · Modified: 10

## Added units
- **[382] Mobile Brigada** / MOBILE BRIGADA — 27-38 pts
- **[296] Corregidor Alguaciles** / CORREGIDOR ALGUACILES — 10-18 pts

## Removed units
- **[424] Lunokhod Sputniks** / LUNOKHOD Sputnik — was 25-26 pts

## Modified units
### [1544] Vostok Sputniks  / VOSTOK Sputniks
- **Points:** 35-40 → 34-38
- **Weapons added:** Light Shotgun, Spitfire
- **Weapons removed:** Mk12(PS=4)

### [1608] Mother Healer Agatha Wabara / MOTHER HEALER AGATHA WABARA
- **Points:** 31-32 → 31

### [1555] Wolfgang Amadeus Wolff, Wulver Bounty Hunter / WOLFGANG AMADEUS WOLFF, Wulver Bounty Hunter
- **Points:** 34 → 33
- **Weapons added:** E/M Grenades(+1SD), MULTI Rifle(+1SD)
- **Weapons removed:** E/M Grenades(+1B), MULTI Rifle(+1B)

### [423] Tsyklon Sputniks / TSYKLON Sputnik
- **Points:** 26-28 → 26-29

### [408] Stempler Zonds / STEMPLER ZONDS
- **Points:** 15-18 → 15-22
- **Weapons added:** Thunderbolt(+1B)
- **Skills added:** BS=12, Super-Jump

### [10325] Bashi Bazouks / BASHI BAZOUKS
- **Points:** 13-16 → 12-16
- **Weapons added:** Contender(+1SD)
- **Weapons removed:** Contender(+1B)

### [11072] Emily Handelman, Intel Agent / EMILY HANDELMAN, Intel Agent
- **Points:** 23-24 → 22-24

### [10122] CSU, Corporate Security Unit / CSU, Corporate Security Unit
- **Points:** 11-14 → 10-13
- **Weapons removed:** Nanopulser

### [10198] Father Lucien Sforza, Authorized Bounty Hunter / FATHER LUCIEN SFORZA, Authorized Bounty Hunter
- **Points:** 25-28 → 23-26
- **Weapons added:** Adhesive Launcher Rifle, Heavy Pistol
- **Weapons removed:** Adhesive Launcher Rifle(+1B), Heavy Pistol(+1B)
- **Skills added:** BS Attack(+1SD), NCO
- **Equipment added:** Albedo(-6)
- **Equipment removed:** Holomask

### [10947] Major Lunah, ex-Aristeia! Sniper / MAJOR LUNAH, ex-Aristeia! Sniper
- **Points:** 28 → 29
- **Weapons added:** VIRAL Sniper Rifle(+1SD)
- **Weapons removed:** VIRAL Sniper Rifle
